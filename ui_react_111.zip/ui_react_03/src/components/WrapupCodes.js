import React, { useState } from 'react';
import axios from 'axios';
import FileUpload from './FileUpload';
import CSVPreview from './CSVPreview';

const WrapupCodes = ({ token, onBack }) => {
  const [dataList, setDataList] = useState([]);
  const [csvPreviewComplete, setCsvPreviewComplete] = useState(false);
  const [fileUploaded, setFileUploaded] = useState(false);
  const [uploadError, setUploadError] = useState(null);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  const handleFileUpload = (data) => {
    setDataList(data);
    setFileUploaded(true);
    setCsvPreviewComplete(false);
    setUploadError(null);
    setUploadSuccess(false);
  };

  const handleCSVPreviewComplete = () => {
    setCsvPreviewComplete(true);
  };

  const createWrapupCodeBatch = async () => {
    if (!token || dataList.length === 0) return;

    const API_URL_WRAPUPCODE = 'https://api.usw2.pure.cloud/api/v2/routing/wrapupcodes';
    const headers = {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    try {
      await Promise.all(dataList.map(wrapupCodeData => {
        const { name, divisionId, divisionName } = wrapupCodeData;
        const payload = {
          name,
          division: { id: divisionId || "", name: divisionName || "" }
        };
        return axios.post(API_URL_WRAPUPCODE, payload, { headers });
      }));
      setUploadSuccess(true);
      setUploadError(null);
    } catch (error) {
      console.error('Error creating wrapup codes:', error.response ? error.response.data : error.message);
      setUploadError(error.response ? error.response.data : error.message);
      setUploadSuccess(false);
    }
  };

  return (
    <div>
      {!fileUploaded && !uploadSuccess && !uploadError && (
        <FileUpload onFileUpload={handleFileUpload} label="Upload Wrapup Codes CSV" />
      )}
      {fileUploaded && !uploadSuccess && !uploadError && (
        <>
          <CSVPreview data={dataList} uploadType="wrapupcode" onComplete={handleCSVPreviewComplete} />
          <button onClick={createWrapupCodeBatch} disabled={!csvPreviewComplete}>
            Send to Genesys
          </button>
        </>
      )}
      
      {uploadSuccess && <div className="success-message">Wrapup codes created successfully!</div>}
      {uploadError && <div className="error-message">Failed to create wrapup codes: {JSON.stringify(uploadError)}</div>}
      
      <button onClick={onBack} className="back-button">Back</button>
    </div>
  );
};

export default WrapupCodes;
