import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import Papa from 'papaparse';

const FileUpload = ({ onFileUpload, label }) => {
  const onDrop = useCallback((acceptedFiles) => {
    acceptedFiles.forEach(file => {
      Papa.parse(file, {
        header: true,
        skipEmptyLines: true,
        complete: (results) => {
          const filteredData = results.data.filter(row =>
            Object.values(row).some(value => value.trim() !== "")
          );
          console.log('Parsing complete:', filteredData);
          onFileUpload(filteredData);
        },
        error: (error) => {
          console.error('Error parsing CSV:', error);
          alert('Error parsing CSV file. Please try again.');
        }
      });
    });
  }, [onFileUpload]);

  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    multiple: true, // Allow multiple files
    accept: '.csv, text/csv' // Specify accepted file types
  });

  return (
    <div className="dropzone" {...getRootProps()}>
      <input {...getInputProps()} />
      <p>{label}</p>
    </div>
  );
};

export default FileUpload;
