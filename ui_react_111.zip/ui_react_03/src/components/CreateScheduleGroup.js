import React, { useState } from 'react';
import axios from 'axios';
import PropTypes from 'prop-types';
import FileUpload from './FileUpload';
import CSVPreview from './CSVPreview';

const CreateScheduleGroup = ({ token, onBack }) => {
  const [csvData, setCsvData] = useState([]);
  const [uploadError, setUploadError] = useState(null);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  const handleFileUpload = data => {
    setCsvData(data);
  };

  const parseSchedules = (schedules) => {
    if (!schedules) return [];
    return schedules.split(',').map(id => ({ id: id.trim() }));
  };

  const handleCreateScheduleGroup = async () => {
    if (!token || csvData.length === 0) return;

    const API_URL = 'https://api.usw2.pure.cloud/api/v2/architect/schedulegroups';
    const headers = {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    try {
      const transformedDataList = csvData.map((rowData) => ({
        name: rowData.name || '',
        division: { id: rowData.divisionid || '' },
        timeZone: rowData.timeZone || '',
        openSchedules: parseSchedules(rowData.openSchedules),
        closedSchedules: parseSchedules(rowData.closedSchedules),
        holidaySchedules: parseSchedules(rowData.holidaySchedules),
      }));

      await Promise.all(
        transformedDataList.map((payload) =>
          axios.post(API_URL, payload, { headers })
        )
      );
      setUploadSuccess(true);
      setUploadError(null);
    } catch (error) {
      console.error('Error creating group schedule:', error.response ? error.response.data : error.message);
      setUploadError(error.response ? error.response.data : error.message);
      setUploadSuccess(false);
    }
  };

  return (
    <div className="schedule-group-container">
      {csvData.length === 0 && !uploadSuccess && !uploadError && (
        <FileUpload onFileUpload={handleFileUpload} label="Browse CSV File" />
      )}
      {csvData.length > 0 && !uploadSuccess && !uploadError && (
        <CSVPreview data={csvData} />
      )}
      {csvData.length > 0 && !uploadSuccess && !uploadError && (
        <button onClick={handleCreateScheduleGroup} disabled={!token || csvData.length === 0}>
          Send to Genesys
        </button>
      )}

      {uploadSuccess && <div className="success-message">All group schedules created successfully!</div>}
      {uploadError && <div className="error-message">Failed to create group schedule: {JSON.stringify(uploadError)}</div>}

      <button onClick={onBack} className="back-button">Back</button>
    </div>
  );
};

CreateScheduleGroup.propTypes = {
  token: PropTypes.string.isRequired,
  onBack: PropTypes.func.isRequired
};

export default CreateScheduleGroup;
