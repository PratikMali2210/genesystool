import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { SpeechConfig, AudioConfig, SpeechRecognizer } from 'microsoft-cognitiveservices-speech-sdk';
import '../App.css';

const SpeechToText = ({ onTranscription }) => {
  const [transcribing, setTranscribing] = useState(false);

  const onDrop = useCallback((acceptedFiles) => {
    const sdk = require('microsoft-cognitiveservices-speech-sdk');
    const speechConfig = SpeechConfig.fromSubscription('B0a8ba456a3d427d9de7c86bd84ed041', 'eastasia');

    acceptedFiles.forEach((file) => {
      setTranscribing(true);
      const audioConfig = AudioConfig.fromWavFileInput(file);
      const recognizer = new SpeechRecognizer(speechConfig, audioConfig);

      recognizer.recognizeOnceAsync(result => {
        if (result.reason === sdk.ResultReason.RecognizedSpeech) {
          const fileName = file.name.replace(/\.wav$/, ''); // Remove .wav extension
          onTranscription(fileName, result.text);
        } else {
          console.error('Error recognizing speech:', result.errorDetails);
          alert('Error recognizing speech. Please try again.');
        }
        setTranscribing(false);
      });
    });
  }, [onTranscription]);

  const { getRootProps, getInputProps } = useDropzone({ onDrop, multiple: true, accept: '.wav' });

  return (
    <div {...getRootProps()} className="dropzone">
      <input {...getInputProps()} />
      <p>Browse Audio Files</p>
      {transcribing && <p className="transcribing">Transcribing...</p>}
    </div>
  );
};

export default SpeechToText;
