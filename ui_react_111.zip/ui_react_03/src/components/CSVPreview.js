import React, { useEffect, useState } from 'react';

const CSVPreview = ({ data, uploadType, onComplete }) => {
  const [isProcessing, setIsProcessing] = useState(true);

  useEffect(() => {
    if (data.length > 0) {
      const timer = setTimeout(() => {
        setIsProcessing(false);
        if (onComplete) onComplete(); // Ensure onComplete is called after processing is done
      }, 1000);

      return () => clearTimeout(timer);
    } else {
      setIsProcessing(false);
    }
  }, [data, onComplete]);

  // Function to convert data to CSV format and create a download link
  const downloadCSV = () => {
    const headers = Object.keys(data[0]);
    const csvRows = [
      headers.join(','),
      ...data.map(row => headers.map(header => JSON.stringify(row[header] || '')).join(','))
    ];

    const csvString = csvRows.join('\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `preview_${uploadType}_data.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (data.length === 0) return null;

  return (
    <div className="csv-preview">
      <h2>
        {uploadType === 'user' ? 'People CSV Preview' : 
         uploadType === 'queue' ? 'Queue CSV Preview' : 
         uploadType === 'wrapupcode' ? 'Wrapup Codes CSV Preview' : 
         uploadType === 'skill' ? 'Skills CSV Preview' : 
         uploadType === 'language' ? 'Languages CSV Preview' : 
         uploadType === 'prompt' ? 'Prompt CSV Preview' : 
         uploadType === 'schedule' ? 'Schedule CSV Preview' : 
         uploadType === 'schedulegroup' ? 'Schedule Group CSV Preview' : ''}
      </h2>
      {isProcessing && <p className="processing-message">Still Processing...</p>}
      {!isProcessing && data.length === 0 && <p>No data to display.</p>}
      <table>
        <thead>
          <tr>
            {Object.keys(data[0]).map((key) => (
              <th key={key}>
                {uploadType === 'prompt' && key === 'description' ? 'Text To Speech / Text' : key}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row, index) => (
            <tr key={index}>
              {Object.entries(row).map(([key, value], i) => (
                <td key={i}>
                  {key === 'name' ? value.replace(/\.wav$/, '') : value}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {!isProcessing && <p className="processing-complete">CSV data ready to send to Genesys!</p>}
      {!isProcessing && uploadType === 'prompt' && (
        <button onClick={downloadCSV} className="download-csv-button">Download CSV</button>
      )}
    </div>
  );
};

export default CSVPreview;
