import React, { useState } from 'react';
import axios from 'axios';
import FileUpload from './FileUpload';
import CSVPreview from './CSVPreview';

const Languages = ({ token, onBack }) => {
  const [dataList, setDataList] = useState([]);
  const [csvPreviewComplete, setCsvPreviewComplete] = useState(false);
  const [fileUploaded, setFileUploaded] = useState(false);
  const [uploadError, setUploadError] = useState(null);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  const handleFileUpload = (data) => {
    setDataList(data);
    setFileUploaded(true); // Set fileUploaded to true after file is uploaded
    setCsvPreviewComplete(false); // Reset csvPreviewComplete when a new file is uploaded
    setUploadError(null); // Clear any previous errors
    setUploadSuccess(false); // Clear previous success message
  };

  const handleCSVPreviewComplete = () => {
    setCsvPreviewComplete(true); // Set csvPreviewComplete to true when CSV preview is done
  };

  const createLanguagesBatch = async () => {
    if (!token || dataList.length === 0) return;

    const API_URL_LANGUAGES = 'https://api.usw2.pure.cloud/api/v2/routing/languages';
    const headers = {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    try {
      await Promise.all(dataList.map(languageData => {
        const { name } = languageData;
        const payload = { name };
        return axios.post(API_URL_LANGUAGES, payload, { headers });
      }));
      setUploadSuccess(true); // Set success state
      setUploadError(null); // Clear previous errors
    } catch (error) {
      console.error('Error creating languages:', error.response ? error.response.data : error.message);
      setUploadError(error.response ? error.response.data : error.message); // Set error state
      setUploadSuccess(false); // Clear success message
    }
  };

  return (
    <div>
      {!fileUploaded && !uploadSuccess && !uploadError && (
        <FileUpload onFileUpload={handleFileUpload} label="Upload Languages CSV" />
      )}
      {fileUploaded && !uploadSuccess && !uploadError && (
        <>
          <CSVPreview data={dataList} uploadType="language" onComplete={handleCSVPreviewComplete} />
          <button onClick={createLanguagesBatch} disabled={!csvPreviewComplete}>
            Send to Genesys
          </button>
        </>
      )}
      
      {uploadSuccess && <div className="success-message">Languages created successfully!</div>}
      {uploadError && <div className="error-message">Failed to create languages: {JSON.stringify(uploadError)}</div>}
      
      <button onClick={onBack} className="back-button">Back</button>
    </div>
  );
};

export default Languages;
