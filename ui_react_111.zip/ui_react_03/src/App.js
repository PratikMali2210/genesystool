import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';
import capgeminiLogo from './assets/Capgemini-logo.png';
import genesysLogo from './assets/Genesys-logo.png';
import CSVPreview from './components/CSVPreview';
import FileUpload from './components/FileUpload';
import SpeechToText from './components/SpeechToText';
import CreateScheduleGroup from './components/CreateScheduleGroup';
import WrapupCodes from './components/WrapupCodes';
import Skills from './components/Skills';
import Languages from './components/Languages';

const stripExtension = (filename) => {
  return filename.replace(/\.[^/.]+$/, '');
};

function App() {
  const [token, setToken] = useState('');
  const [dataList, setDataList] = useState([]);
  const [uploadType, setUploadType] = useState('');
  const [isFetchingToken, setIsFetchingToken] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [uploadError, setUploadError] = useState(null);
  const [csvPreviewComplete, setCsvPreviewComplete] = useState(false);

  useEffect(() => {
    if (isFetchingToken || token) return;

    setIsFetchingToken(true);

    const getToken = async () => {
      try {
        const response = await axios.post('http://localhost:5000/api/token');
        const accessToken = response.data.access_token;
        setToken(accessToken);
      } catch (error) {
        console.error('Error retrieving token:', error);
        alert('Failed to retrieve token. Please try again later.');
      } finally {
        setIsFetchingToken(false);
      }
    };

    getToken();
  }, [isFetchingToken, token]);

  const handleFileUpload = (data) => {
    setDataList(data);
  };

  const handleTranscription = (fileName, transcription) => {
    setDataList(prevDataList => [
      ...prevDataList,
      { name: stripExtension(fileName), description: transcription }
    ]);
  };

  const createUserBatch = async () => {
    if (!token || dataList.length === 0 || uploadType !== 'user') return;

    const API_URL_USER = 'https://api.usw2.purecloud/api/v2/users';
    const headers = {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    try {
      await Promise.all(dataList.map(userData => {
        const { name, email, divisionId } = userData;
        return axios.post(API_URL_USER, { name, email, divisionId }, { headers });
      }));
      setUploadSuccess(true);
    } catch (error) {
      console.error('Error creating users:', error.response ? error.response.data : error.message);
      setUploadError(error.response ? error.response.data : error.message);
    }
  };

  const createQueueBatch = async () => {
    if (!token || dataList.length === 0 || uploadType !== 'queue') return;

    const API_URL_QUEUE = 'https://api.usw2.pure.cloud/api/v2/routing/queues';
    const headers = {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    try {
      await Promise.all(dataList.map(queueData => {
        const { name, divisionId, divisionName } = queueData;
        return axios.post(API_URL_QUEUE, { name, division: { id: divisionId, name: divisionName } }, { headers });
      }));
      setUploadSuccess(true);
    } catch (error) {
      console.error('Error creating queues:', error.response ? error.response.data : error.message);
      setUploadError(error.response ? error.response.data : error.message);
    }
  };

  const createPromptBatch = async () => {
    if (!token || dataList.length === 0 || uploadType !== 'prompt') return;

    const API_URL_PROMPT = 'https://api.usw2.pure.cloud/api/v2/architect/prompts';
    const headers = {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    try {
      await Promise.all(dataList.map(async promptData => {
        const { name, description } = promptData;
        await axios.post(API_URL_PROMPT, { name, description }, { headers });

        // Add a delay before the GET request
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Additional GET request after the POST request
        const API_URL_PROMPT_SEARCH = `${API_URL_PROMPT}?nameOrDescription=*${name}*`;
        const response = await axios.get(API_URL_PROMPT_SEARCH, { headers });
        console.log('Prompt search response:', response.data);

        const promptId = response.data.entities[0].id; // assuming the first result is the correct one

        const ttsData = {
          language: 'en-us',
          ttsString: description
        };

        const API_URL_TTS = `${API_URL_PROMPT}/${promptId}/resources`;
        await axios.post(API_URL_TTS, ttsData, { headers });
      }));
      setUploadSuccess(true);
    } catch (error) {
      console.error('Error creating prompts:', error.response ? error.response.data : error.message);
      setUploadError(error.response ? error.response.data : error.message);
    }
  };

  const createScheduleBatch = async () => {
    if (!token || dataList.length === 0 || uploadType !== 'schedule') return;

    const API_URL_SCHEDULE = 'https://api.usw2.pure.cloud/api/v2/architect/schedules';
    const headers = {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    try {
      await Promise.all(dataList.map(scheduleData => {
        const { name, divisionId, start, end, rrule } = scheduleData;
        return axios.post(API_URL_SCHEDULE, { name, division: { id: divisionId }, start, end, rrule }, { headers });
      }));
      setUploadSuccess(true);
    } catch (error) {
      console.error('Error creating schedules:', error.response ? error.response.data : error.message);
      setUploadError(error.response ? error.response.data : error.message);
    }
  };

  const createScheduleGroupBatch = async () => {
    if (!token || dataList.length === 0 || uploadType !== 'schedulegroup') return;

    const API_URL = 'https://api.usw2.pure.cloud/api/v2/architect/schedulegroups';
    const headers = {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    try {
      await Promise.all(dataList.map(scheduleGroupData => {
        const { name, divisionId, timeZone, openSchedules, closedSchedules, holidaySchedules } = scheduleGroupData;
        return axios.post(API_URL, {
          name,
          division: { id: divisionId },
          timeZone,
          openSchedules,
          closedSchedules,
          holidaySchedules
        }, { headers });
      }));
      setUploadSuccess(true);
    } catch (error) {
      console.error('Error creating schedule groups:', error.response ? error.response.data : error.message);
      setUploadError(error.response ? error.response.data : error.message);
    }
  };

  const createWrapupCodeBatch = async () => {
    if (!token || dataList.length === 0 || uploadType !== 'wrapupcode') return;

    const API_URL_WRAPUPCODE = 'https://api.usw2.purecloud/api/v2/routing/wrapupcodes';
    const headers = {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    try {
      await Promise.all(dataList.map(wrapupCodeData => {
        const { name, divisionId, divisionName } = wrapupCodeData;
        return axios.post(API_URL_WRAPUPCODE, {
          name,
          division: { id: divisionId, name: divisionName }
        }, { headers });
      }));
      setUploadSuccess(true);
    } catch (error) {
      console.error('Error creating wrapup codes:', error.response ? error.response.data : error.message);
      setUploadError(error.response ? error.response.data : error.message);
    }
  };

  const createSkillsBatch = async () => {
    if (!token || dataList.length === 0 || uploadType !== 'skill') return;

    const API_URL_SKILLS = 'https://api.usw2.purecloud/api/v2/routing/skills';
    const headers = {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    try {
      await Promise.all(dataList.map(skillData => {
        const { name } = skillData;
        const payload = { name };
        return axios.post(API_URL_SKILLS, payload, { headers });
      }));
      setUploadSuccess(true);
    } catch (error) {
      console.error('Error creating skills:', error.response ? error.response.data : error.message);
      setUploadError(error.response ? error.response.data : error.message);
    }
  };

  const createLanguagesBatch = async () => {
    if (!token || dataList.length === 0 || uploadType !== 'language') return;

    const API_URL_LANGUAGES = 'https://api.usw2.purecloud/api/v2/administration/languages';
    const headers = {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    try {
      await Promise.all(dataList.map(languageData => {
        const { languageCode, name } = languageData;
        const payload = { languageCode, name };
        return axios.post(API_URL_LANGUAGES, payload, { headers });
      }));
      setUploadSuccess(true);
    } catch (error) {
      console.error('Error creating languages:', error.response ? error.response.data : error.message);
      setUploadError(error.response ? error.response.data : error.message);
    }
  };

  const resetApp = () => {
    setUploadType('');
    setDataList([]);
    setUploadSuccess(false);
    setUploadError(null);
    setCsvPreviewComplete(false);
  };

  return (
    <div className="App">
      <div className="logos">
        <img src={capgeminiLogo} alt="Capgemini Logo" className="logo capgemini-logo" />
        <img src={genesysLogo} alt="Genesys Logo" className="logo genesys-logo" />
      </div>
      
      <h1 className="app-title">Genesys Cloud Custom Tool</h1>

      {!uploadType && !uploadSuccess && !uploadError && (
        <div>
          <button onClick={() => setUploadType('user')}>Add People</button>
          <button onClick={() => setUploadType('queue')}>Add Queues</button>
          <button onClick={() => setUploadType('prompt')}>Add Prompt</button>
          <button onClick={() => setUploadType('schedule')}>Add Schedule</button>
          <button onClick={() => setUploadType('schedulegroup')}>Add Schedule Group</button>
          <button onClick={() => setUploadType('wrapupcode')}>Add Wrapup Codes</button>
          <button onClick={() => setUploadType('skill')}>Add Skills</button>
          <button onClick={() => setUploadType('language')}>Add Languages</button>
        </div>
      )}

      {uploadType && !uploadSuccess && !uploadError && (
        <div>
          {uploadType === 'schedulegroup' ? (
            <CreateScheduleGroup token={token} onBack={resetApp} />
          ) : uploadType === 'wrapupcode' ? (
            <WrapupCodes token={token} onBack={resetApp} />
          ) : uploadType === 'skill' ? (
            <Skills token={token} onBack={resetApp} />
          ) : uploadType === 'language' ? (
            <Languages token={token} onBack={resetApp} />
          ) : (
            <div>
              {!dataList.length ? (
                uploadType === 'prompt' ? (
                  <SpeechToText onTranscription={handleTranscription} />
                ) : (
                  <FileUpload onFileUpload={handleFileUpload} label="Browse CSV Files" />
                )
              ) : (
                <CSVPreview data={dataList} uploadType={uploadType} onComplete={() => setCsvPreviewComplete(true)} />
              )}
              <div className="button-group">
                {dataList.length > 0 && uploadType === 'prompt' && csvPreviewComplete && (
                  <button onClick={() => {
                    if (uploadType === 'user') {
                      createUserBatch();
                    } else if (uploadType === 'queue') {
                      createQueueBatch();
                    } else if (uploadType === 'prompt') {
                      createPromptBatch();
                    } else if (uploadType === 'schedule') {
                      createScheduleBatch();
                    } else if (uploadType === 'wrapupcode') {
                      createWrapupCodeBatch();
                    } else if (uploadType === 'schedulegroup') {
                      createScheduleGroupBatch();
                    } else if (uploadType === 'skill') {
                      createSkillsBatch();
                    } else if (uploadType === 'language') {
                      createLanguagesBatch();
                    }
                  }} disabled={!token || dataList.length === 0}>
                    Send to Genesys
                  </button>
                )}
                {dataList.length > 0 && uploadType !== 'prompt' && (
                  <button onClick={() => {
                    if (uploadType === 'user') {
                      createUserBatch();
                    } else if (uploadType === 'queue') {
                      createQueueBatch();
                    } else if (uploadType === 'schedule') {
                      createScheduleBatch();
                    } else if (uploadType === 'wrapupcode') {
                      createWrapupCodeBatch();
                    } else if (uploadType === 'schedulegroup') {
                      createScheduleGroupBatch();
                    } else if (uploadType === 'skill') {
                      createSkillsBatch();
                    } else if (uploadType === 'language') {
                      createLanguagesBatch();
                    }
                  }} disabled={!token || dataList.length === 0}>
                    Send to Genesys
                  </button>
                )}
                <button onClick={resetApp} className="back-button">Back</button>
              </div>
            </div>
          )}
        </div>
      )}

      {uploadSuccess && (
        <div>
          <h2>Upload Successful!</h2>
          <button onClick={resetApp}>Go to Home</button>
        </div>
      )}

      {uploadError && (
        <div>
          <h2>Upload Failed!</h2>
          <p>Error: {JSON.stringify(uploadError)}</p>
          <button onClick={resetApp} className="back-button">Back</button>
        </div>
      )}
    </div>
  );
}

export default App;
